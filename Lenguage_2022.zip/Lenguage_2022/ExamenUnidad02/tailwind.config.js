module.exports = {
  content: [
    './components/**/*.{html,js}',
    './views/**/*.{html,js,ejs}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
